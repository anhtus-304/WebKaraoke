﻿namespace WebKaraoke.Data;

public class Class1
{

}
