namespace WebKaraoke.Data.Entities
{
    public class KhachHang
    {
        public int KhachHangID { get; set; }
        public string HoTen { get; set; }
        public string SoDienThoai { get; set; }
        public string Email { get; set; }
        public string DiaChi { get; set; }
    }
}