﻿namespace WebKaraoke.DTO
{
    public class PhongDto
    {
        public int PhongID { get; set; }
        public string TenPhong { get; set; }
        public string LoaiPhong { get; set; }
        public string TrangThai { get; set; }
    }
}