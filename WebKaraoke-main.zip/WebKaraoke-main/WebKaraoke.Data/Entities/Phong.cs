namespace WebKaraoke.Data.Entities
{
    public class Phong
    {
        public int PhongID { get; set; }
        public string TenPhong { get; set; }
        public string LoaiPhong { get; set; }
        public decimal GiaGio { get; set; }
        public string TrangThai { get; set; }
    }
}