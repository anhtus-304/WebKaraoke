namespace WebKaraoke.Data.Entities
{
    public class NhanVien
    {
        public int NhanVienID { get; set; }
        public string HoTen { get; set; }
        public string SoDienThoai { get; set; }
        public string ChucVu { get; set; }
    }
}